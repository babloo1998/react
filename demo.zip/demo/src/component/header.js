import React , {Component} from 'react';
import '../css/header.css';
class Header extends Component{
    render()
    {
        return(
            <header>
                <p>Header</p>
                <p>counter = {this.props.name}</p>
            </header>
        )
    }
}
export default Header;