import React , {Component} from 'react';
import App from '../App';
import '../css/footer.css';
class Footer extends Component{
    render(){
        return(
            <footer>
                Footer
            </footer>
        )
    }
}
export default Footer;