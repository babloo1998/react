import React, { Component } from 'react';
import Header from './component/header'
import Main from './component/main'
import Footer from './component/footer'
import './App.css';

class App extends Component {
 constructor(){
   super();
   this.state={
     counter : 0
   }
 }
 count = ()=>{
   this.state.counter++;
   this.setState(
     {
       counter : this.state.counter 
     }
   );
 }

  render() {
  return (
      <div className="App">
            <Header name = {this.state.counter}/>
             <Main info = {this.count}/>
             <Footer/>
      </div>
    );
  }
}

export default App;
